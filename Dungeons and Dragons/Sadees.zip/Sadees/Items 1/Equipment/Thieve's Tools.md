**Ability:** Dexterity  
**Utilize:** Pick a lock (DC 15), or disarm a trap (DC 15)

If you have proficiency with a tool, add your Proficiency Bonus to any ability check you make that uses the tool. If you have proficiency in a skill that’s used with that check, you have Advantage on the check too.