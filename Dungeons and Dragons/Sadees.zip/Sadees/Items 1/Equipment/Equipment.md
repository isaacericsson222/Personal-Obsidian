#equipment

[[Explorers Pack]]
[[Thieve's Tools]]
[[Traveler's Clothes]]
[[Artisans Tools]]
[[Letter of Introduction]]
