**Rapier  
Melee weapon (martial, rapier)

**_Finesse._** When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls.

**Damage**: 1d8  
**Damage Type**: Piercing
**Properties**: Finesse
**Weight**: 2