_Melee weapon (simple, dagger)_

**_Finesse._** When making an attack with a finesse weapon, you use your choice of your Strength or Dexterity modifier for the attack and damage rolls. You must use the same modifier for both rolls.

**_Light._** A light weapon is small and easy to handle, making it ideal for use when fighting with two weapons.

**Damage:** 1d4  
**Damage Type:** Piercing  
**Properties:** Finesse, Light, Range, Thrown  
**Range:** 20/60  
**Weight:** 1