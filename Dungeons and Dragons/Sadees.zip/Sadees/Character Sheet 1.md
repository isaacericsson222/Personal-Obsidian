#character

race: human 1
class: rogue
size: medium
alignment: chaotic-good
ac: 
hp: 8
current hp: 8
hit dice: 1d8
speed: 30
stats:
 - STR -  7 (-2)
 - DEX - 17(+3)
 - CON - 11 (+0)
 - INT - 17 (+4)
 - WIS -  11(+0)
 - CHA -  12(+1)
saves:
 - DEX (+5)
 - INT (+5)
skillsaves: slight of hand, investigation, perception(Expertise), insight(Expert), history, persuasion(Expertise), deception, intimidation
passive perception: 10
languages: common, elvish
initiative: +3
[[Me/Dungeons and Dragons/Sadees/Features 1/Features|Features]]
 - Feat Skill Expert
  - Expertise
  - Sneak Attack
  - Thieve's Can't
[[Me/Dungeons and Dragons/Sadees/Items 1/Equipment/Equipment|Equipment]]
- explorers pack
- thieves tool
- artisans tools
- a letter of introduction
- travelers clothes
[[Me/Dungeons and Dragons/Sadees/Items 1/Weapons/Weapons|Weapons]]
 - rapier
 - shortbow + 20 arrows
 - daggers (2)
other proficiencies and languages
 - light armor
 - simple weapons, hand crossbows, longswords, rapiers, shortswords
 - thieves tools, artisans tools
 spellcasting
 spell save DC: 
 spell attack mod: 
 focus: glasses
 - Cantrips
 - 1st Level
 - 2nd Level
 - 3rd Level
 - 4th Level
 - 5th Level
 - 6th Level
 - 7th Level
 - 8th Level
 - 9th Level
 - 10th Level


 
 
 
