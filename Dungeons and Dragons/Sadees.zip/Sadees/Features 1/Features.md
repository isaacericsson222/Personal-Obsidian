#features

[[Expertise]]
[[Skill Expert (Feat)]]
[[Sneak Attack]]
[[Thieve's Can't]]