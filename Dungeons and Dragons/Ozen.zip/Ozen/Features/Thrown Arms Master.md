You’ve honed your ability to lob weaponry into the fray, including weapons not meant for ranged combat. You gain the following benefits:

- Increase your Strength or Dexterity score by 1, to a maximum of 20.
- Simple and martial melee weapons without the thrown property have the thrown property for you. One-handed weapons have a normal range of 20 feet and a long range of 60 feet, while two-handed weapons have a normal range of 15 feet and a long range of 30 feet.
- Weapons that already have the thrown property increase their short range by 20 feet and their long range by 40 feet for you.
- When you miss with a thrown weapon attack using a light weapon, the weapon returns to your grasp like a boomerang at the end of your turn, unless something prevents it from returning. You can catch and stow as many weapons as you threw in this way.