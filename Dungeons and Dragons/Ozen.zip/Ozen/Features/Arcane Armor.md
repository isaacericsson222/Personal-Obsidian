Beginning at 3rd level, your metallurgical pursuits have led to you making armor a conduit for your magic. As an action, you can turn a suit of armor you are wearing into Arcane Armor, provided you have smith's tools in hand.

You gain the following benefits while wearing this armor:

- If the armor normally has a Strength requirement, the arcane armor lacks this requirement for you.

- You can use the arcane armor as a spellcasting focus for your artificer spells.

- The armor attaches to you and can’t be removed against your will. It also expands to cover your entire body, although you can retract or deploy the helmet as a bonus action. The armor replaces any missing limbs, functioning identically to a body part it is replacing.

- You can doff or don the armor as an action.

The armor continues to be Arcane Armor until you don another suit of armor or you die.