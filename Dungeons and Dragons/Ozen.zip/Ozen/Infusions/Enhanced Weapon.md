**_tem: A simple or martial weapon_**

This magic weapon grants a +1 bonus to attack and damage rolls made with it.

The bonus increases to +2 when you reach 10th level in this class.