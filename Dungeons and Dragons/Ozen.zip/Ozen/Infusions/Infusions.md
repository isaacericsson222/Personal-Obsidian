[[Armor of Strength]]
[[Enhanced Weapon]]
[[Enhanced Defense]]
[[Returning Weapon]]
