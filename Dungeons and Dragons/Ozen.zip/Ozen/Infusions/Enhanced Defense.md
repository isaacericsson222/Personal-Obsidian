**_Item: A suit of armor or a shield_**

A creature gains a +1 bonus to Armor Class while wearing (armor) or wielding (shield) the infused item.

The bonus increases to +2 when you reach 10th level in this class.