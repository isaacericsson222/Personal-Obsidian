#character

race: human 4
class: artificer
background: noble
size: medium
alignment: chaotic-neutral
ac: 14
hp: 30
current hp: 19
hit dice: 3d8
speed: 30
gold: 25
stats:
 - STR -  12 (+1)
 - DEX - 11 (+0)
 - CON - 13 (+1)
 - INT - 17 (+3)
 - WIS - 12 (+1)
 - CHA - 10 (+0)
saves:
 - CON (+3)
 - INT (+5)
 skillsaves:
  - Arcana (+5) INT
  - Perception (+4) WIS
  - History (+5) INT
  - Persuasion (+2) CHA
passive perception: 11
initiative: +0
Infusions
Infused Items

[[Me/Dungeons and Dragons/Ozen/Features/Features|Features]]
 - Arcane Armor
 - Armor Model
 - The Right Tool for the Job
 - Thrown Arms Master
 - Tinkering
[[Infusions]]
 - Armor of Strength
 - Enhanced Defense
 - Enhanced Weapon
 - Returning Weapon
[[Me/Dungeons and Dragons/Ozen/Items/Equipment/Equipment|Equipment]]
 - Gaming set
 - Signet ring
 - Scroll of pedigree
 - Fine clothes
 - Desecrate
 - Stronghold
[[Me/Dungeons and Dragons/Ozen/Items/Weapons/Weapons|Weapons]]
 - Dagger
 - Serrated Boomerangs
other proficiencies and languages
 - light armor, medium armor, shields
 - simple weapons, light crossbows
 - common, 2 other languages
 characteristics
  - Personality Trait
	  - If you do me an injury, I will crush you, ruin your name, and salt your fields.
  - Ideal
	  - **Independence.** I must prove that I can handle myself without the coddling of my family. (Chaotic)
  - Bonds
	  - I will face any challenge to win the approval of my family.
  - Flaws
	  - By my words and actions, I often bring shame to my family.



 
![[Pasted image 20250411173317.png]]