[[Dagger]]
[[Serrated Boomerangs]]