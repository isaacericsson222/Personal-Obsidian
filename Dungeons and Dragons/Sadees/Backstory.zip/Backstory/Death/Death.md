3rd day of campaign
Killed by Duegar through an unfortunately high damaging attack and tough save roles.

Death has changed Sadees, he no longer finds humor in things and it is only used as a tool to persuade or ridicule. His ambition has been anything but quenched and his desire to prove his dueling prowess has increased tenfold. As well he recognizes his skills in ledger work and dealings to be the means to which he can achieve fame and recognition, both of which will allow him to return home a hero and man strong enough to finally show his father.