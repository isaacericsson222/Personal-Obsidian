Sadees has 3 siblings

Jushu 
- older brother that has a crippling gambling addiction, cast out by father at 15 and often in precarious positions of debt. Pawned off many of the estates wealth to fuel his cravings

Alain
 - younger brother who is viewed as simple to father. Somehow though finds beauty in the most mundane objects. Always admired my handwriting. 

Alexandre
 - older brother who father respected in a way that usually was not apparent. Faced the brunt of the beatings as he could withstand them more than the rest of us. Left us as soon as he won his 3rd dual and father broke Alain's leg.

Céline
 - mother who after an affair and several near death experiences with father has gone into a wordless stupor, no longer willing to talk or find the motivation to live.